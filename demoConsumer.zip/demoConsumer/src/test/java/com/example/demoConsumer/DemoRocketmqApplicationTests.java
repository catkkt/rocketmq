package com.example.demoConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRocketmqApplicationTests {

    @Test
    void contextLoads() {
    }

}
